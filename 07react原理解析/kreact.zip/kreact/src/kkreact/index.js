import Component from './Component'
import createElement from './createElement'


// 重点就是这俩API 和ReactDOM.js
let React = {
    createElement,
    Component
}


export default React